var studydata = [
	{
		img : "traffic/monorail.jpg", 
		Japanese : "モノレール",
		JapaneseSample : "モノレールで空港へ行く",
		Chinese : "单轨列车",
		ChineseSample : "我乘坐单轨列车去机场", 
		English : "Monorail",
		EnglishSample : "I go to airport by monorail"
	},
	{
		img : "traffic/dumpcar.jpg", 
		Japanese : "ダンプカー",
		JapaneseSample : "私はダンプカーが大好きです",
		Chinese : "翻斗车",
		ChineseSample : "我很喜欢翻斗车", 
		English : "dump car",
		EnglishSample : "I like dump car"
	},
	{
		img : "traffic/policecar.jpg", 
		Japanese : "パトカー  (パトロールカー )",
		JapaneseSample : "パトカーは格好いい"
	},
	{
		img : "traffic/tanker.jpg", 
		Japanese : "タンカー", 
		JapaneseSample : "マンモス・タンカー"
	},
	{
		img : "traffic/bulldozer.png", 
		Japanese : "ブルドーザー", 
		JapaneseSample : "ブルドーザーでならす"
	},
	{
		img : "traffic/autobicycle.jpg", 
		Japanese : "オートバイ", 
		JapaneseSample : "オートバイの遠乗り",
		English : "auto bicycle",
		EnglishSample : "Ride an auto bicycle"
	},
	{
		img : "traffic/yacht.jpg", 
		Japanese : "ヨット", 
		JapaneseSample : "ヨット遊びに行く"
	},
	{
		img : "traffic/helicopter.jpg", 
		Japanese : "ヘリコプター", 
		JapaneseSample : "救急用ヘリコプター"
	},
	{
		img : "traffic/aircraftcarrier.jpg", 
		Japanese : "空母 (くうぼ　航空母艦　こうくうぼかん)", 
		JapaneseSample : "空母がもっとも強い戦艦です",
		Chinese : "航空母舰  航母",
		ChineseSample : "航母是最强大的战船", 
		English : "Aircraft carrier",
		EnglishSample : "The  aircraft carrier is the most powerful battleship"
	},
	{
		img : "animal/1.png", 
		Japanese : "動物集合(1)", 
		JapaneseSample : "動物集合1"
	},
	{
		img : "animal/2.png", 
		Japanese : "動物集合(2)", 
		JapaneseSample : "動物集合2"
	},
	{
		img : "animal/3.png", 
		Japanese : "動物集合(3)", 
		JapaneseSample : "動物集合3"
	},
	{
		img : "animal/4.png", 
		Japanese : "動物集合(4)", 
		JapaneseSample : "動物集合4"
	},
	{
		img : "animal/5.png", 
		Japanese : "動物集合(5)", 
		JapaneseSample : "動物集合5"
	},
	{
		img : "animal/6.png", 
		Japanese : "動物集合(6)", 
		JapaneseSample : "動物集合6"
	},
	{
		img : "animal/7.png", 
		Japanese : "動物集合(7)", 
		JapaneseSample : "動物集合7"
	},
	{
		img : "animal/8.png", 
		Japanese : "動物集合(8)", 
		JapaneseSample : "動物集合8"
	},
	{
		img : "animal/9.png", 
		Japanese : "動物集合(9)", 
		JapaneseSample : "動物集合9"
	},
	{
		img : "animal/10.png", 
		Japanese : "動物集合(10)", 
		JapaneseSample : "動物集合10"
	},
	{
		img : "animal/11.png", 
		Japanese : "動物集合(11)", 
		JapaneseSample : "動物集合11"
	},
	{
		img : "animal/12.png", 
		Japanese : "動物集合(12)", 
		JapaneseSample : "動物集合12"
	},
	{
		img : "animal/13.png", 
		Japanese : "動物集合(13)", 
		JapaneseSample : "動物集合13"
	},
	{
		img : "animal/14.png", 
		Japanese : "動物集合(14)", 
		JapaneseSample : "動物集合14"
	},
	{
		img : "animal/15.png", 
		Japanese : "動物集合(15)", 
		JapaneseSample : "動物集合15"
	},
	{
		img : "animal/16.png", 
		Japanese : "動物集合(16)", 
		JapaneseSample : "動物集合16"
	},
	{
		img : "animal/17.png", 
		Japanese : "動物集合(17)", 
		JapaneseSample : "動物集合17"
	},
	{
		img : "animal/18.png", 
		Japanese : "動物集合(18)", 
		JapaneseSample : "動物集合18"
	},
	{
		img : "animal/19.png", 
		Japanese : "動物集合(19)", 
		JapaneseSample : "動物集合19"
	},
	{
		img : "animal/20.png", 
		Japanese : "動物集合(20)", 
		JapaneseSample : "動物集合20"
	},
	{
		img : "animal/21.png", 
		Japanese : "動物集合(21)", 
		JapaneseSample : "動物集合21"
	},
	{
		img : "animal/macaro.jpg", 
		Japanese : "マグロ", 
		JapaneseSample : "マグロを刺身にする"
	},
	{
		img : "animal/shark.jpg", 
		Japanese : "サメ", 
		JapaneseSample : "サメは海の中に一番怖い生物です"
	},
	{
		img : "animal/fugu.jpg", 
		Japanese : "フグ（河豚）", 
		JapaneseSample : "河豚中毒"
	},
	{
		img : "animal/porgy.jpg", 
		Japanese : "鯛（たい）", 
		JapaneseSample : "くさっても鯛",
		English : "red sea bream",
		EnglishSample : "An old eagle is better than a young crow"
	},
	{
		img : "animal/ray.jpg", 
		Japanese : "エイ", 
		JapaneseSample : "エイがかわいい",
		Chinese : "鳐鱼",
		ChineseSample : "鳐鱼好可爱",
		English : "ray",
		EnglishSample : "Ray is cute"
	},
	{
		img : "animal/goldfish.jpg", 
		Japanese : "きんぎょ（金魚）", 
		JapaneseSample : "きんぎょを飼う"
	},
	{
		img : "animal/goldfish1.jpg", 
		Japanese : "でめきん(出目金)", 
		JapaneseSample : "でめきんは大きな目がある",
		Chinese : "凸眼金鱼",
		ChineseSample : "凸眼金鱼长着一双大眼睛",
		English : "Pop-eyed goldfish",
		EnglishSample : "Pop-eyed goldfish have big eyes"
	},
	{
		img : "animal/Medaka.jpg", 
		Japanese : "メダカ", 
		JapaneseSample : "メダカを飼う",
		English : "medaka",
		EnglishSample : "Keep a medaka"
	},
	{
		img : "animal/catfish.jpg", 
		Japanese : "ナマズ", 
		JapaneseSample : "ナマズ料理がおいしいです"
	},
	{
		img : "animal/crucian.jpg", 
		Japanese : "フナ（鮒）", 
		JapaneseSample : "フナはきんぎょが進化する前の魚です",
		Chinese : "鲫鱼",
		ChineseSample : "鲫鱼是金鱼进化前的鱼",		
		English : "Crucian",
		EnglishSample : "Crucian is the ancestor of goldfish"
	},
	{
		img : "animal/deepseafish.jpg", 
		Japanese : "チョウチンアンコウ（提燈鮟鱇）", 
		JapaneseSample : "チョウチンアンコウは深い海に住んでいる",
		Chinese : "鮟鱇鱼",
		ChineseSample : "鮟鱇鱼生活在深海里",		
		English : "Atlantic footballfish",
		EnglishSample : " "
	},
		{
		img : "animal/sunfish.jpg",
		Japanese : "マンボウ", 
		JapaneseSample : "マンボウの体がでかいです",
		EnglishSample : "Sunfish has a big body"
	},			
	{
		img : "animal/flounder.jpg",
		Japanese : "ヒラメ", 
		JapaneseSample : "ヒラメの目が片側にあります",
		English : "flounder",
		EnglishSample : "Flounder's eyes situated on one side of its head"
	},
	{
		img : "animal/Flyingfish.gif",
		Japanese : "トビウオ", 
		JapaneseSample : "トビウオは海の上を飛び跳ねる",
		Chinese : "飞鱼",
		ChineseSample : "飞鱼在大海的上空跳跃着飞翔",		
		English : "Flying fish",
		EnglishSample : "Flying fish is bouncing over the sea"
	},
	{
		img : "animal/denki-unagi.jpg",
		Japanese : "でんきウナギ（電気鰻）", 
		JapaneseSample : "でんきウナギは驚くほどの電気を蓄積しています",
		Chinese : "电鳗",
		ChineseSample : "电鳗是一个惊人的电量存储库",		
		English : "electric eel",
		EnglishSample : "The electric eel is an amazing storage battery"
	},
	{
		img : "animal/sake.png",
		Japanese : "サケ（シャケ・鮭）", 
		JapaneseSample : "サケのたまごをイラクとよび、お寿司で食べられる",
		Chinese : "大麻哈鱼 三文鱼",
		ChineseSample : "三文鱼的卵可以当作寿司吃",		
		English : "Oncorhynchus",
		EnglishSample : "Oncorhynchus's eggs are eated as Sushi"
	},
	{
		img : "animal/koi.png",
		Japanese : "コイ（鯉）", 
		JapaneseSample : "コイの滝登りが有名です。こいのぼりのモデルです",
		Chinese : "鲤鱼",
		ChineseSample : "鲤鱼迎着瀑布逆流而上十分有名。是日本的鲤鱼旗的由来",		
		English : "Cyprinus carpio",
		EnglishSample : "Cyprinus carpio is beautiful"
	},
	{
		img : "animal/piranha.png",
		Japanese : "ピラニア", 
		JapaneseSample : "ピラニアはアマゾン川等南アメリカの熱帯地方に生息する肉食の淡水魚の総称です",
		Chinese : "中国俗称为食人鱼",
		ChineseSample : "食人鱼是对对生活在南美洲热带亚马逊森林里的肉食性淡水鱼的总称",		
		English : "piranha",
		EnglishSample : "Locals in the Amazon region often use piranha teeth to make tools and weapons"
	},
	{
		img : "animal/arowana.jpg",
		Japanese : "アロワナ", 
		JapaneseSample : "アロワナは淡水に生息する大型の古代魚です",
		Chinese : "中国俗称为金龙鱼",
		ChineseSample : "金龙鱼由于长的像传说中的龙，所以在中国受到特别的喜爱",		
		English : "Arowana",
		EnglishSample : "Yellow Arowana is very expensive in China"
	},
	{
		img : "animal/archerfish.png",
		Japanese : "テッポウウオ（鉄砲魚）", 
		JapaneseSample : "テッポウウオは水鉄砲でえものを落として捕まえる",
		Chinese : "射水鱼",
		ChineseSample : "射水鱼从口中喷水射落小动物来捕捉食物",		
		English : "Archer Fish",
		EnglishSample : " "
	},
	{
		img : "animal/hari.png",
		Japanese : "ハリセンボン", 
		JapaneseSample : "危ない時、ハリセンボンは体を大きく膨らませる",
		Chinese : "刺鲀",
		ChineseSample : "遇到危险的时候，刺鲀会把身体涨大吓走敌人",		
		English : "Diodontidae",
		EnglishSample : " "
	},
	{
		img : "animal/kasago.png",
		Japanese : "カサゴ", 
		JapaneseSample : "赤い体ととげとげしいせなかのヒレがカサゴのとくちょうです",
		Chinese : "鲉鱼 石头鱼 石斑",
		ChineseSample : "红色的身体和尖锐的背鳍是石头鱼的特征",		
		English : "？",
		EnglishSample : "？"
	},
	{
		img : "animal/Amphiprion.png",
		Japanese : "カクレクマノミ", 
		JapaneseSample : "カクレクマノミはディズニー映画の中によくあらわれる",
		Chinese : "小丑鱼",
		ChineseSample : "小丑鱼经常在迪斯尼电影中出现",		
		English : "Amphiprion",
		EnglishSample : "？"
	},
	{
		img : "animal/nannyouhagi.png",
		Japanese : "ナンヨウハギ", 
		JapaneseSample : "ナンヨウハギはサンゴの近くに住んでいる",
		Chinese : "刺尾鱼",
		ChineseSample : "刺尾鱼生活在珊瑚附近",		
		English : "Paracanthurus",
		EnglishSample : "？"
	},
	{
		img : "animal/fue.png",
		Japanese : "フエヤッコダイ", 
		JapaneseSample : "フエヤッコダイはほそながいくちで岩のすきまのエサを取る",
		Chinese : "深黄镊口鱼　蝴蝶鱼 笛奴鯛",
		ChineseSample : "镊口鱼用又长又细的嘴从岩石缝中找食物",		
		English : "Forcipiger flavissimus",
		EnglishSample : "？"
	},
	{
		img : "animal/whale.png",
		Japanese : "クジラ", 
		JapaneseSample : "クジラは魚ではありません",
		Chinese : "鲸鱼",
		ChineseSample : "鲸鱼不是鱼类，是哺乳动物",		
		English : "whale",
		EnglishSample : "The whale is not a fish"
	},
	{
		img : "animal/dolphin.png",
		Japanese : "イルカ", 
		JapaneseSample : "イルカの脳はサイズは大きい",
		Chinese : "海豚",
		ChineseSample : "海豚大脑的体积很大",		
		English : "Dolphin",
		EnglishSample : "Dolphins sometimes play in the wake of the boats"
	},
	{
		img : "animal/syati.png",
		Japanese : "シャチ(鯱)", 
		JapaneseSample : "シャチは時には群れでクジラをおそう",
		Chinese : "虎鲸　逆戟鲸",
		ChineseSample : "虎鲸是海豚的一种，是大海中最凶猛的动物",		
		English : "Orcinus orca",
		EnglishSample : ""
	},
	{
		img : "animal/enhydra.jpg",
		Japanese : "ラッコ", 
		JapaneseSample : "ラッコは貝を食べます",
		Chinese : "海獭",
		ChineseSample : "海獭吃贝类的时候，常仰泳并用石块杂碎贝壳",		
		English : "Enhydra",
		EnglishSample : "Enhydra eats shellfish"
	},
	{
		img : "animal/bat.png",
		Japanese : "コウモリ(蝙蝠)", 
		JapaneseSample : "コウモリはネズミのなかまです。鳥ではない",
		Chinese : "蝙蝠",
		ChineseSample : "蝙蝠和老鼠是近亲，不是鸟",		
		English : "bat",
		EnglishSample : "The bat was a mouse. Not a bird"
	},
	{
		img : "animal/",
		Japanese : "ゴリラ", 
		JapaneseSample : "",
		Chinese : "",
		ChineseSample : "",		
		English : "",
		EnglishSample : ""
	},
	{
		img : "animal/chimpanzee.png",
		Japanese : "チンパンジー", 
		JapaneseSample : "チンパンジーは人間と一番似ている動物と言われています",
		Chinese : "黑猩猩",
		ChineseSample : "黑猩猩被认为是和人类最接近的动物",		
		English : "chimpanzee",
		EnglishSample : "Chimpanzee is the cleverest animal"
	},
	{
		img : "animal/gorilla.png",
		Japanese : "ゴリラ", 
		JapaneseSample : "ゴリラが胸をたたくのは敵をいかくするため",
		Chinese : "大猩猩",
		ChineseSample : "大猩猩捶胸是为了威吓敌人",		
		English : "gorilla",
		EnglishSample : "？"
	},
	{
		img : "animal/koala.png",
		Japanese : "コアラ", 
		JapaneseSample : "コアラはユーカリの葉っぱが大好物です",
		Chinese : "考拉熊",
		ChineseSample : "考拉熊非常喜欢吃桉树叶",		
		English : "Koala",
		EnglishSample : "The koala likes eucalyptus leaf very much"
	},
	{
		img : "animal/camel.jpg",
		Japanese : "ラクダ", 
		JapaneseSample : "ラクダに乗るのは楽だ",
		Chinese : "骆驼",
		ChineseSample : "骑骆驼很轻松",		
		English : "Camel",
		EnglishSample : "It is easy to ride a camel"
	},
	{
		img : "animal/mogura.png",
		Japanese : "モグラ", 
		JapaneseSample : "モグラが穴を掘って、その中で生活している",
		Chinese : "鼹鼠",
		ChineseSample : "鼹鼠挖洞生活",		
		English : "Mole",
		EnglishSample : "Moles dug a hole and then live in it"
	},
	{
		img : "animal/manntohihi.png",
		Japanese : "マントヒヒ", 
		JapaneseSample : "マントヒヒの背中にマントを羽織ったような長い毛が生えている",
		Chinese : "狒狒",
		ChineseSample : "狒狒的背上像披着斗篷一样的长毛。",		
		English : "Baboon",
		EnglishSample : "A baboon has long hair on the back as if it puts a cloak"
	},
	{
		img : "animal/musasabi.png",
		Japanese : "ムササビ", 
		JapaneseSample : "ムササビは体をパラシュートのように広げて空を飛ぶ",
		Chinese : "鼯鼠",
		ChineseSample : "鼯鼠身体像降落伞一样展开在天空飞翔",		
		English : "Flying squirrel",
		EnglishSample : "The flying squirrel is Flying in the sky just like a parachute open body "
	},
	{
		img : "animal/panda.jpg",
		Japanese : "パンダ", 
		JapaneseSample : "パンダは中国に生息している",
		Chinese : "大熊猫",
		ChineseSample : "大熊猫来自中国",		
		English : "panda",
		EnglishSample : "Panda is from China"
	},
	{
		img : "animal/smallpanda.png",
		Japanese : "レッサーパンダ", 
		JapaneseSample : "レッサーパンダはパンダではなく、アライグマの仲間です",
		Chinese : "小熊猫",
		ChineseSample : "小熊猫不是熊猫，它和浣熊是亲戚",		
		English : "Lesser panda",
		EnglishSample : "Lesser panda is not panda. it is close to raccoon"
	},
	{
		img : "animal/araiguma.png",
		Japanese : "アライグマ", 
		JapaneseSample : "エサを食べる時、手を洗っているように見える",
		Chinese : "浣熊",
		ChineseSample : "浣熊吃东西的时候就像洗手一样",		
		English : "Raccoon",
		EnglishSample : "When Raccoon eat the food, it looks like washing hands"
	},
	{
		img : "animal/skunk.png",
		Japanese : "スカンク", 
		JapaneseSample : "スカンクはとても臭いオナラをして敵から身を守る",
		Chinese : "臭鼬",
		ChineseSample : "受到攻击时臭鼬会发出一种难闻的气味",		
		English : "skunk",
		EnglishSample : "The skunk gives off an unpleasant smell when attacked"
	},
	{
		img : "animal/harimouse.png",
		Japanese : "ハリネズミ", 
		JapaneseSample : "ハリネズミは体をおおっているはりで敵から身を守っている",
		Chinese : "刺猬",
		ChineseSample : "刺猬披着满身的刺保护自己的身体",		
		English : "Hedgehog",
		EnglishSample : "？"
	},
	{
		img : "animal/kangaroo.png",
		Japanese : "カンガルー", 
		JapaneseSample : "動物園へカンガルーを見に行きます",
		Chinese : "袋鼠",
		ChineseSample : "去动物园看袋鼠",		
		English : "Kangaroo",
		EnglishSample : "Go to the zoo to see kangaroos"
	},
	{
		img : "animal/sai.png",
		Japanese : "サイ", 
		JapaneseSample : "サイの頭に１本または2本の硬い角を持つ",
		Chinese : "犀牛",
		ChineseSample : "犀牛的头上长有1个或2个很硬的角",		
		English : "Rhino",
		EnglishSample : "The Rhino have one or two hard horns in head"
	},
	{
		img : "animal/kaba.png",
		Japanese : "カバ", 
		JapaneseSample : "おとなしそうに見えるけどほんとはカバの足がはやいです",
		Chinese : "河马",
		ChineseSample : "看上去很慢的河马，实际上跑的很快",		
		English : "Hippo",
		EnglishSample : "It Looks meek, but the hippo is fast"
	},
	{
		img : "animal/mantis.jpg", 
		Japanese : "カマキリ", 
		JapaneseSample : "カマキリは小さな昆虫を食べる",
		Chinese : "螳螂",
		ChineseSample : "螳螂吃小昆虫",
		English : "Mantis",
		EnglishSample : "Mantis eats small insects"
	}	
]
